UI Sounds for the PSMC Super Mario Galaxy skin.
