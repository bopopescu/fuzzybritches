GUI Sounds for the PSMC's Super Mario Galaxy skin
